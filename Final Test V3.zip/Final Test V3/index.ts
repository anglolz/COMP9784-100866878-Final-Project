import express from "express";
import dotenv from "dotenv";
import userRouter from "./routes/user";

dotenv.config();

const app = express();

app.use(express.json());

app.get("/", (req, res) => {
  res
    .status(200)
    .json({ message: "Welcome to my API oh my god I hope this works please my head hurts" });
});

app.use("/user", userRouter);

app.use(
  (
    err: Error,
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) => {
    console.error(err);
    res.status(500).json({
      status: "error",
      message: "Request timed out.",
    });
  }
);

const PORT = parseInt(process.env.PORT || "3000", 10);
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
