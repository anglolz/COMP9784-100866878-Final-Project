import { Router } from "express";
import {
  signUp,
  activateUser,
  sendActivationToken,
} from "../controllers/userController";

const router = Router();

router.put("/signup", signUp);

router.get("/activate/:email/:activationToken", activateUser);

router.get("/sendActivationToken/:email", sendActivationToken);

export default router;
