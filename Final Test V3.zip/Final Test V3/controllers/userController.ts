import { RequestHandler } from "express";
import pool from "../db";
import bcrypt from "bcrypt";
import jwt, { SignOptions } from "jsonwebtoken";
import { sendActivationEmail } from "../services/mailer";
import dotenv from "dotenv";
dotenv.config();

const saltRounds = 10;
const jwtSecret: string = process.env.JWT_SECRET as string;
const jwtExpiresIn: string = process.env.JWT_EXPIRES_IN as string;

function buildActivationLink(
  email: string,
  token: string,
  reqUrl: string
): string {
  return `${process.env.SERVER_URL}:${process.env.PORT}/user/activate/${email}/${token}`;
}

export const signUp: RequestHandler = async (req, res) => {
  try {
    const { firstName, lastName, email, password } = req.body;

    if (!firstName || !lastName || !email || !password) {
      res.status(200).json({
        status: "failure",
        message: "Missing required fields",
      });
      return;
    }

    const [existing] = await pool.query(
      "SELECT * FROM user_registrations WHERE email = ?",
      [email]
    );
    if (Array.isArray(existing) && existing.length > 0) {
      res.status(200).json({
        status: "failure",
        message: "Email already registered",
      });
      return;
    }

    const hashedPassword = await bcrypt.hash(password, saltRounds);

    await pool.query(
      "INSERT INTO user_registrations (firstName, lastName, email, password) VALUES (?, ?, ?, ?)",
      [firstName, lastName, email, hashedPassword]
    );

    const token = jwt.sign({ email }, jwtSecret, {
      expiresIn: jwtExpiresIn,
    } as SignOptions);
    const activationLink = buildActivationLink(email, token, req.originalUrl);

    await sendActivationEmail(email, activationLink);

    res.status(200).json({
      status: "success",
      message:
        "Registration successful. Please check your email to activate your account.",
    });
    return;
  } catch (err) {
    console.error(err);
    res.status(500).json({
      status: "error",
      message: "Request timed out.",
    });
    return;
  }
};

export const activateUser: RequestHandler = async (req, res) => {
  try {
    const { email, activationToken } = req.params;

    let decoded: any;
    try {
      decoded = jwt.verify(activationToken, jwtSecret);
    } catch (error) {
      res.status(200).json({
        status: "failure",
        message: "Invalid or expired activation token",
      });
      return;
    }

    if (decoded.email !== email) {
      res.status(200).json({
        status: "failure",
        message: "Email mismatch",
      });
      return;
    }

    await pool.query(
      "UPDATE user_registrations SET emailVerified = true WHERE email = ?",
      [email]
    );

    res.status(200).json({
      status: "success",
      message: `Account activated for ${email}`,
    });
    return;
  } catch (err) {
    console.error(err);
    res.status(500).json({
      status: "error",
      message: "Request timed out.",
    });
    return;
  }
};

export const sendActivationToken: RequestHandler = async (req, res) => {
  try {
    const { email } = req.params;

    const [rows]: any = await pool.query(
      "SELECT * FROM user_registrations WHERE email = ?",
      [email]
    );
    if (!Array.isArray(rows) || rows.length === 0) {
      res.status(200).json({
        status: "failure",
        message: "Email not found",
      });
      return;
    }
    const user = rows[0];
    if (user.emailVerified) {
      res.status(200).json({
        status: "failure",
        message: "Email is already verified",
      });
      return;
    }

    const token = jwt.sign({ email }, jwtSecret, {
      expiresIn: jwtExpiresIn,
    } as SignOptions);
    const activationLink = buildActivationLink(email, token, req.originalUrl);

    await sendActivationEmail(email, activationLink);

    res.status(200).json({
      status: "success",
      message: "Activation email sent",
    });
    return;
  } catch (err) {
    console.error(err);
    res.status(500).json({
      status: "error",
      message: "Request timed out.",
    });
    return;
  }
};
