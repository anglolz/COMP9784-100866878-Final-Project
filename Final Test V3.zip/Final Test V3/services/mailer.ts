import nodemailer from "nodemailer";
import dotenv from "dotenv";
dotenv.config();

const transporter = nodemailer.createTransport({
  service: process.env.EMAIL_SERVICE,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

export async function sendActivationEmail(
  email: string,
  activationLink: string
) {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: "Activate Your Account :-)",
    text: `Click the following link to activate your account: ${activationLink}`,
    html: `<p>Click the following link to activate your account:</p>
           <a href="${activationLink}">${activationLink}</a>`,
  };

  return transporter.sendMail(mailOptions);
}
