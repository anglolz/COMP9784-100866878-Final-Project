import { Router } from "express";
import {
  assignLicensePlate,
  revokeLicensePlate,
  verifyLicensePlate,
} from "../controllers/licensePlateController";

const router = Router();

router.put("/assign/:vin", assignLicensePlate);
router.post("/revoke/:vin", revokeLicensePlate);
router.get("/verify/:licensePlate", verifyLicensePlate);

export default router;
