DROP DATABASE license_db;

CREATE DATABASE IF NOT EXISTS license_db;
USE license_db;

CREATE TABLE IF NOT EXISTS license_plate_assignments (
  licensePlate VARCHAR(7) PRIMARY KEY,
  vin VARCHAR(17) UNIQUE,
  createdAt DATETIME
);

INSERT INTO license_plate_assignments (licensePlate, vin, createdAt)
VALUES
  ('AAAA000', '1HGCM82633A123456', NOW()),
  ('AAAA001', '1HGCM82633A654321', NOW()),
  ('AAAA002', '1HGCM82633A000000', NOW());

SELECT * FROM license_plate_assignments;