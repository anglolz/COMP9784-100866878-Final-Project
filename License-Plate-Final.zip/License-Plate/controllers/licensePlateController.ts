import { RequestHandler } from "express";
import {
  getAssignmentByVin,
  getAssignmentByPlate,
  getLastAssignedPlate,
  createAssignment,
  deleteAssignmentByVin,
} from "../db";

const vinRegex = /^(?!.*[IOQioq])[A-HJ-NPR-Za-hj-npr-z0-9]{17}$/;
const licensePlateRegex = /^[A-Z]{4}[0-9]{3}$/;

function generateNextLicensePlate(lastPlate: string | null): string {
  if (!lastPlate) {
    return "AAAA000";
  }
  const letters = lastPlate.slice(0, 4);
  const numbers = lastPlate.slice(4);
  let num = parseInt(numbers, 10);
  if (num < 999) {
    num++;
    return letters + num.toString().padStart(3, "0");
  } else {
    let letterArr = letters.split("");
    let i = letterArr.length - 1;
    while (i >= 0) {
      if (letterArr[i] !== "Z") {
        letterArr[i] = String.fromCharCode(letterArr[i].charCodeAt(0) + 1);
        break;
      } else {
        letterArr[i] = "A";
        i--;
      }
    }
    const newLetters = letterArr.join("");
    return newLetters + "000";
  }
}

export const assignLicensePlate: RequestHandler = async (req, res) => {
  try {
    let { vin } = req.params;
    vin = vin.toUpperCase();

    if (!vinRegex.test(vin)) {
      res.status(200).json({
        status: "failure",
        message: `vin: ${vin} is invalid`,
      });
      return;
    }

    const existingAssignment = await getAssignmentByVin(vin);
    if (existingAssignment) {
      res.status(200).json({
        status: "success",
        message: `licensePlate: ${existingAssignment.licensePlate} is assigned to vin: ${vin}.`,
      });
      return;
    }

    const lastAssignment = await getLastAssignedPlate();
    const lastPlate = lastAssignment ? lastAssignment.licensePlate : null;
    const newPlate = generateNextLicensePlate(lastPlate);

    await createAssignment(newPlate, vin);

    res.status(200).json({
      status: "success",
      message: `licensePlate: ${newPlate} is assigned to vin: ${vin}.`,
    });
    return;
  } catch (err) {
    console.error(err);
    res.status(500).json({
      status: "error",
      message: "Request timed out.",
    });
    return;
  }
};

export const revokeLicensePlate: RequestHandler = async (req, res) => {
  try {
    let { vin } = req.params;
    vin = vin.toUpperCase();

    if (!vinRegex.test(vin)) {
      res.status(200).json({
        status: "failure",
        message: `vin: ${vin} is invalid`,
      });
      return;
    }

    const existingAssignment = await getAssignmentByVin(vin);
    if (!existingAssignment) {
      res.status(200).json({
        status: "failure",
        message: `No license plate assigned to vin: ${vin}`,
      });
      return;
    }

    await deleteAssignmentByVin(vin);

    res.status(200).json({
      status: "success",
      message: `licensePlate: ${existingAssignment.licensePlate} was revoked from vin: ${vin}`,
    });
    return;
  } catch (err) {
    console.error(err);
    res.status(500).json({
      status: "error",
      message: "Request timed out.",
    });
    return;
  }
};

export const verifyLicensePlate: RequestHandler = async (req, res) => {
  try {
    const { licensePlate } = req.params;

    if (!licensePlateRegex.test(licensePlate)) {
      res.status(200).json({
        status: "failure",
        message: `licensePlate: ${licensePlate} is invalid`,
      });
      return;
    }

    const assignment = await getAssignmentByPlate(licensePlate);
    if (assignment) {
      res.status(200).json({
        status: "success",
        message: `licensePlate: ${licensePlate} is assigned to vin: ${assignment.vin}.`,
      });
      return;
    } else {
      res.status(200).json({
        status: "success",
        message: `licensePlate: ${licensePlate} is not assigned.`,
      });
      return;
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({
      status: "error",
      message: "Request timed out.",
    });
    return;
  }
};
