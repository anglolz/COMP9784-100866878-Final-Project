import mysql from "mysql2/promise";
import dotenv from "dotenv";
dotenv.config();

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

export async function getAssignmentByVin(vin: string): Promise<any> {
  const [rows] = await pool.query(
    "SELECT * FROM license_plate_assignments WHERE vin = ?",
    [vin]
  );
  return Array.isArray(rows) && rows.length > 0 ? rows[0] : null;
}


export async function getAssignmentByPlate(licensePlate: string): Promise<any> {
  const [rows] = await pool.query(
    "SELECT * FROM license_plate_assignments WHERE licensePlate = ?",
    [licensePlate]
  );
  return Array.isArray(rows) && rows.length > 0 ? rows[0] : null;
}

export async function getLastAssignedPlate(): Promise<any> {
  const [rows] = await pool.query(
    "SELECT licensePlate FROM license_plate_assignments ORDER BY licensePlate DESC LIMIT 1"
  );
  return Array.isArray(rows) && rows.length > 0 ? rows[0] : null;
}

export async function createAssignment(
  licensePlate: string,
  vin: string
): Promise<any> {
  const createdAt = new Date().toISOString();
  const [result] = await pool.query(
    "INSERT INTO license_plate_assignments (licensePlate, vin, createdAt) VALUES (?, ?, ?)",
    [licensePlate, vin, createdAt]
  );
  return result;
}

export async function deleteAssignmentByVin(vin: string): Promise<any> {
  const [result] = await pool.query(
    "DELETE FROM license_plate_assignments WHERE vin = ?",
    [vin]
  );
  return result;
}
