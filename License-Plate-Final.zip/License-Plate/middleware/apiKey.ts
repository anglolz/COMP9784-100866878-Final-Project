import { RequestHandler } from "express";

const apiKeyMiddleware: RequestHandler = (req, res, next) => {
  const apiKey = req.header("x-api-key");
  const validApiKey = process.env.API_KEY || "default_api_key";
  if (apiKey !== validApiKey) {
    res.status(403).json({
      status: "failure",
      message: "Invalid API Key",
    });
    return;
  }
  next();
};

export default apiKeyMiddleware;
